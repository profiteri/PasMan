package com.example.app.activity_main

object User {
    var fakeToken: String? = "tocken"
}