# PasMan
Lokal password manager

In the app you can store 4 different types of entries: 
1. Accounts (login + password + other information)
2. Cards
3. Identities (name + adress)
4. Notes

All the data are stored in a SQLite database and additionaly encrypted.
